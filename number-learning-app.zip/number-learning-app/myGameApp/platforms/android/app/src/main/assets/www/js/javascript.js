// Add event listener to go back button
document.getElementById('go-back').addEventListener('click', () => {
  window.location.href = 'learning_options.html';
});
